﻿#https://stackoverflow.com/questions/46928536/htmlagilitypack-in-combination-with-powershell-windows-authentification
#https://github.com/PowerShell/SmartPackageProvider
#http://www.leeholmes.com/blog/2010/03/05/html-agility-pack-rocks-your-screen-scraping-world/
#http://poshadmin.de/?p=975

#Register-PackageSource -Name NugetP -ProviderName Nuget -Location https://www.nuget.org/api/v2/ -Trusted
#Install-Package -Source NugetP -Name HtmlAgilityPack -Force -Verbose

#$Nuget = "C:\Program Files\PowerShell\6.0.0.14\Modules\Pester\vendor\tools\NuGet.exe"
#.$Nuget install HtmlAgilityPack 

#.$Nuget sources -Name https://www.nuget.org/api/v2/ enable 

#https://social.technet.microsoft.com/Forums/windowsserver/en-US/753c6b04-4411-46d4-b19d-67e686ffc1cf/finding-html-elements-using-xpath?forum=winserverpowershell
#http://www.westerndevs.com/simple-powershell-automation-browser-based-tasks/
#https://www.linkedin.com/pulse/20140814051217-328790935-getting-information-from-web-pages-via-powershell
#https://social.technet.microsoft.com/Forums/ie/en-US/95ce08b7-20cc-4ff8-9311-8aa5e6f81782/save-webpage-as-mhthtml-file-in-powershell?forum=winserverpowershell
#https://stackoverflow.com/questions/47587888/how-to-save-a-web-page-into-a-html-file-with-powershell-or-c

$zipCodesOld = @(
75041
75042
75040
75044
75048
75098
75094
75002
75074
75025
75023
75024
75075
75093
75287
75252
75248
75254
75240
75243
75080
75081
75082
75044
)

#around 75252
$zipCodes = @(
75248
75254
75080
75081
75082
75075
75074
75023
75044
)
<#
#http://ddctrep.bnymellon.net/Reports/Pages/Folder.aspx

#$cred = Get-Credential AMS\xbbnntg

#$webrequest = invoke-webrequest -Uri http://ddctrep.bnymellon.net/Reports/Pages/Folder.aspx -Credential AMS\xbbnntg
#$webrequest = invoke-webrequest -Uri http://ddctrep.bnymellon.net/Reports/Pages/Folder.aspx -Credential $cred
#$webrequest.StatusCode
#$webrequest.StatusDescription


#$urlNum = $urls.length
#Write-Output "----------- URL ACCESS TEST -------------"
#Write-Output "URL tested: $urlNum "

#For($i = 0; $i -lt $zipCodes.Length; $i++){
foreach ($zipCode in $zipCodes) {
    $url = "https://www.realtor.com/realestateandhomes-search/$zipCode/beds-2/price-na-200000"
    #try {
    #Test-Connection $server -Count 1 | Select-Object Address, IPV4Address
    #Test-Connection $server -Count 1 -ErrorAction Stop | Select-Object Address, IPV4Address
    $webrequest = invoke-webrequest -Uri $url
    #$status = $webrequest.StatusDescription 
    #$tmp = $url,$status
    #"$tmp"
    #Test-Connection $server -Count 1 -Quiet | Select-Object Address, IPV4Address
    #}
    #catch [System.Net.NetworkInformation.PingException] {
    #Write-Output "$url is offline"
    #}
}

#invoke-webrequest -Uri https://www.realtor.com/realestateandhomes-search/75252/beds-2/price-na-200000
#>

#$Url = 'https://www.realtor.com/realestateandhomes-search/75252/beds-2/price-na-200000'

$Url75252 = 'https://www.realtor.com/realestateandhomes-search/75252/beds-2/price-na-200000?pgsz=50'

$ie = new-object -ComObject "InternetExplorer.Application"
$ie.navigate($Url75252)
$ie.visible = $true
#$ie.silent = $true

For($i = 0; $i -lt $zipCodes.Length; $i++){
#For($i = 0; $i -lt 2; $i++){

$Url = "https://www.realtor.com/realestateandhomes-search/$($zipCodes[$i])/beds-2/price-na-200000?pgsz=50"
#$ie.navigate($Url)
$ie.Navigate2($Url, 0x1000)
while($ie.Busy) { Start-Sleep -Seconds 1 }
#while($ie.ReadyState -ne 4) { Start-Sleep -Seconds 1 }
Start-Sleep -Seconds 1
#$ie.Document.body
#$ie.Document | gm
#$ie.Document.Body | Out-File 'C:\DataLogs\RealEstate\Body.txt' -Force
#$ie.Document.Body.innerHTML  | Out-File 'C:\DataLogs\RealEstate\Body.txt' -Force
#$ie.Document
}
#Start-Sleep 10
#$ie.Document.documentElement.innerHTML | Out-File 'C:\DataLogs\RealEstate\Content.html' -Force
#$ie.Stop()
#$ie.Quit()

#https://stackoverflow.com/questions/17625309/use-getelementsbyclassname-in-a-script
#$ie.Document.getElementById("USER")
#$ie.Document.GetElementsByClassName('search-result-count')
#<span class="search-result-count srp-list-header-count font-bold">            3
#            
#            Homes
#          </span>
