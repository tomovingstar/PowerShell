WELCOME TO HJSPLIT Version 1.4 FOR WINDOWS 95/NT 4.x!

GENERAL:
HJSplit is a freeware utility for Windows 95/NT to split large files into smaller ones. 
HJSplit consists of four files:
HJSplit.exe
HJSplit.ico
HJSplitHelp.txt
Readme.txt

INSTALLATION:
This program can be started directly in Windows from 'run...' in the start menu. It needs no explicit installation procedures.
The icon HJSplit.ico can also be manually added as part of a shortcut into a program-group or start-menu. 
HJSplit.exe can run from a write-protected disk.

USE AND DISTRIBUTION:
When you want to sell this program, or use it commercially, you need the approval of the author.
You may however or distribute an unchanged version HJSplit and charge distribution costs.

FUTURE:
Futre plans for HJSplit:
Automatic checksum tests. 
Automatic split to disks.
Installation procedure.

For remarks/problems/suggestions you can contact me at:

hjh@usa.net
freeware@bigfoot.com
http://www.freebyte.com/freew1.htm

Henk Hagedoorn
Amsterdam, the Netherlands
 
	