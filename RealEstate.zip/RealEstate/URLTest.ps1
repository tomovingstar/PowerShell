﻿
$zipCodes = @(
75041
75042
75040
75044
75048
75098
75094
75002
75074
75025
75023
75024
75075
75093
75287
75252
75248
75254
75240
75243
75080
75081
75082
75044
)


#http://ddctrep.bnymellon.net/Reports/Pages/Folder.aspx

#$cred = Get-Credential AMS\xbbnntg


#$webrequest = invoke-webrequest -Uri http://ddctrep.bnymellon.net/Reports/Pages/Folder.aspx -Credential AMS\xbbnntg
#$webrequest = invoke-webrequest -Uri http://ddctrep.bnymellon.net/Reports/Pages/Folder.aspx -Credential $cred
#$webrequest.StatusCode
#$webrequest.StatusDescription


#$urlNum = $urls.length
#Write-Output "----------- URL ACCESS TEST -------------"
#Write-Output "URL tested: $urlNum "

#For($i = 0; $i -lt $zipCodes.Length; $i++){
foreach ($zipCode in $zipCodes) {
    $url = "https://www.realtor.com/realestateandhomes-search/$zipCode/beds-2/price-na-200000"
    #try {
    #Test-Connection $server -Count 1 | Select-Object Address, IPV4Address
    #Test-Connection $server -Count 1 -ErrorAction Stop | Select-Object Address, IPV4Address
    $webrequest = invoke-webrequest -Uri $url
    #$status = $webrequest.StatusDescription 
    #$tmp = $url,$status
    #"$tmp"
    #Test-Connection $server -Count 1 -Quiet | Select-Object Address, IPV4Address
    #}
    #catch [System.Net.NetworkInformation.PingException] {
    #Write-Output "$url is offline"
    #}
}

#invoke-webrequest -Uri https://www.realtor.com/realestateandhomes-search/75252/beds-2/price-na-200000
#Stop-Transcript